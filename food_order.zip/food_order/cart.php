<?php include("partials-front/menu.php"); ?> 
 <!-- fOOD sEARCH Section Starts Here -->
 
 <section class="food-search text-center">
     <div class="container">
    
<?php
$items = [];
foreach ($_SESSION as $key => $value)
{
    $sub_key = substr($key, 0, 5);
    if ($sub_key == "cart_")
    {
        $id = substr($key, 5);
        array_push($items, $id);
    }
}
$count = 0;
$grand_total = 0;
if(!count($items))
{
    echo "<H1>Your cart is empty.</H1>";
}
else
{
?>
     <table>

    <caption>Your Cart</caption>

<thead>
  <tr>
    <th class="primary">SN</th>
    <th class="primary">Product</th>
    <th class="primary">Price</th>
    <th class="primary">Quantity</th>
    <th class="primary">Total</th>
    <th class="primary">Action</th>
  </tr>
</thead>

<tbody>
<?php
foreach ($items as $item) {
$item_query = "select * from tbl_food where id = $item";
$result =  mysqli_query($conn, $item_query);
$row = mysqli_fetch_assoc($result);
?>
<tr>
    <td><?php echo ++$count; ?></td>
    <td>
        <img src="<?php echo HOMEURL;?>images/food/<?php echo $row['image_name']; ?>"  class="img-responsive img-curve" style="height:50px; width:50px;">
        <br>
        <b><i><?php echo $row['title'] ?></i></b>
    </td>
    <td>RS.<?php echo $row['price']; ?></td>
    <td> <?php echo $_SESSION['cart_' . $item]; ?> Items</td>
    <td>RS. <?php $total =  $row['price'] * $_SESSION['cart_' . $item]; $grand_total += $total; echo $total;?></td>
    <td><a href="<?php echo HOMEURL; ?>remove_from_cart.php?p_id=<?php echo $item; ?>" class="btn btn-primary">remove</a></td>
  </tr>
<?php } ?>  
<tr>
    <td colspan="2"> Grand Total: RS. <?php echo $grand_total ?></td>
    <td colspan="2">  <a href="<?php echo HOMEURL ?>clear_cart.php" class="btn btn-primary">Clear Cart</a></td>
    <?php if (isset($_SESSION['customer_login'])) { ?>
    <td colspan="2"> <a href="<?php echo HOMEURL?>order.php" class="btn btn-primary">Order Now</a></ </td>
    <?php } else { ?>
    <td colspan="2"> <a href="<?php echo HOMEURL?>login.php" class="btn btn-primary">To make order you most login. Click here to login.</a></ </td>
    <?php } ?>   
</tr>
</tbody>

</table>
<?php  } ?>        
     </div>
 </section>
<?php include "partials-front/footer.php" ?>
</body>
</html>
