-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 09, 2022 at 02:19 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `food_order`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `activation_code` int(11) DEFAULT NULL,
  `status` int(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_id`, `name`, `address`, `email`, `phone_no`, `password`, `activation_code`, `status`) VALUES
(1, 'lldld', 'lld', 'gtmaryal100@gmail.com', 'ddfdfd', '827ccb0eea8a706c4c34a16891f84e7b', NULL, 1),
(2, 'Bodhi Aryal', 'ffddd', 'gtmaryal10000@gmail.com', '9847387545', '3c5c7ef80bf7defa378f561073d3ec43', NULL, 1),
(3, 'Gautam Aryal', 'Baluwatar Kathmandu', 'gtmaryal101@gmail.com', '9847387545', '25f9e794323b453885f5181f1b624d0b', NULL, 1),
(4, 'Hari Aryal', 'Palpa, Kahtmandu', 'gtmaryal102@gmail.com', '98473875545', '25f9e794323b453885f5181f1b624d0b', NULL, 1),
(5, 'fflflff', 'ldkllfl', 'gtmaryal105@gmail.com', '9847387545', '25f9e794323b453885f5181f1b624d0b', NULL, 1),
(6, 'Hldkld dldkl', 'ldlkds ddkd', 'gtmaryal151@gmail.com', '9847387545', '25f9e794323b453885f5181f1b624d0b', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `Id` int(10) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`Id`, `full_name`, `username`, `password`) VALUES
(6, 'anil', 'anil', 'pk123 '),
(7, 'admin', 'admin', 'admin'),
(11, 'prashant', 'prashant', 'admin ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `Id` int(10) NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `feature` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`Id`, `title`, `image_name`, `feature`, `active`) VALUES
(29, 'Bites', 'food_catagory_619.jpg', 'yes', 'yes'),
(30, 'Burgers & Pastas', 'food_catagory_868.png', 'no', 'yes'),
(31, 'Desserts', 'food_catagory_272.jpg', 'yes', 'yes'),
(32, 'Dumpling', 'food_catagory_87.jpg', 'yes', 'yes'),
(33, 'Pizzas', 'food_catagory_75.jpg', 'no', 'yes'),
(34, 'rice and noodles', 'food_catagory_575.jpg', 'no', 'yes'),
(35, 'Beverages', 'food_catagory_546.png', 'no', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food`
--

CREATE TABLE `tbl_food` (
  `Id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `feature` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_food`
--

INSERT INTO `tbl_food` (`Id`, `title`, `description`, `price`, `image_name`, `category_id`, `feature`, `active`) VALUES
(48, 'Korean Chili Chicken', 'Made With Italian sauce, chicken and organic vegetable ', '400.00', 'food_catagory_30.jpg', 0, 'no', 'yes'),
(49, 'BBQ Hot Wings', 'Made With Italian sauce, chicken and organic vegetable ', '450.00', 'food_catagory_429.jpg', 0, 'no', 'yes'),
(51, 'Crispy Wings', 'Made With Italian sauce, chicken and organic vegetable ', '300.00', 'food_catagory_127.jpg', 0, 'yes', 'yes'),
(52, 'Mustang Fries', 'Made With Italian sauce, chicken and organic vegetable ', '300.00', 'food_catagory_316.jpg', 29, 'no', 'yes'),
(53, 'Cheesy Fries', 'Made With Italian sauce, chicken and organic vegetable ', '300.00', 'food_catagory_671.jpg', 29, 'no', 'yes'),
(54, 'French Fries', 'Made With Italian sauce, chicken and organic vegetable ', '400.00', 'food_catagory_900.jpg', 29, 'no', 'yes'),
(56, 'Chicken Burger', 'Made With Italian sauce, chicken and organic vegetable ', '400.00', 'food_catagory_262.jpg', 30, 'no', 'yes'),
(57, 'Fish Burger', 'Made With Italian sauce, chicken and organic vegetable ', '400.00', 'food_catagory_71.png', 0, 'yes', 'yes'),
(59, 'Chicken Cream Pasta', 'Made With Italian sauce, chicken and organic vegetable ', '500.00', 'food_catagory_917.jpg', 0, 'yes', 'yes'),
(60, 'Creamy Mushroom Pasta', 'Creamy Mushroom Pasta', '600.00', 'food_catagory_492.jpg', 30, 'no', 'yes'),
(61, 'Kimchi Fried Rice (Non-Veg)', 'Made With Italian sauce, chicken and organic vegetable ', '550.00', 'food_catagory_792.jpg', 0, 'yes', 'yes'),
(62, 'Claypot Chicken Rice', 'Claypot made rice ', '500.00', 'food_catagory_215.jpg', 34, 'no', 'yes'),
(63, 'Claypot Chicken Rice', 'Claypot Chicken Rice', '450.00', 'food_catagory_509.jpg', 0, 'yes', 'yes'),
(66, 'Pizza Margherita (Veg)', 'Pizza Margherita (Veg)', '450.00', 'food_catagory_720.jpg', 33, 'no', 'yes'),
(67, 'Non Veg Deluxe', 'Non Veg Deluxe', '500.00', 'food_catagory_705.jpg', 0, 'yes', 'yes'),
(68, 'Chicken Momo', 'Chicken Momo\r\n', '300.00', 'food_catagory_928.jpg', 32, 'no', 'yes'),
(69, 'Veg Momo', 'Veg Momo', '200.00', 'food_catagory_282.jpg', 0, 'no', 'yes'),
(70, 'Fresh Cheesecake', 'Fresh Cheesecake', '350.00', 'food_catagory_807.jpg', 31, 'no', 'yes'),
(71, 'Super Brownie', 'Super Brownie', '500.00', 'food_catagory_814.jpg', 0, 'no', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `Id` int(11) NOT NULL,
  `food` varchar(150) NOT NULL,
  `price` double(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`Id`, `food`, `price`, `qty`, `total`, `order_date`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`) VALUES
(18, ' goma', 13.00, 2, '39.00', '2022-08-17 03:55:54', 'cancelled', ' prashant', '9845744893', 'drprashantkoirala@gmail.com', 'naki pot lalitpur'),
(19, ' varseee', 12.00, 2, '24.00', '2022-08-17 04:38:22', 'delivered', ' prashant', '9845744893', 'prashant@mail.com', 'hhhhhhhhhhhh'),
(20, ' goma', 13.00, 2, '26.00', '2022-08-17 11:59:00', 'Ordered', ' sads', 'sada', 'p@gmail.com', 'asd'),
(21, 'Fish Burger', 400.00, 1, '400.00', '2022-09-09 16:44:21', 'Ordered', 'Gautam Aryal', '9847387545', 'gtmaryal101@gmail.com', 'Baluwatar Kathmandu'),
(22, 'Fish Burger', 400.00, 1, '400.00', '2022-09-09 16:46:53', 'Ordered', 'Gautam Aryal', '9847387545', 'gtmaryal101@gmail.com', 'Baluwatar Kathmandu'),
(23, 'Kimchi Fried Rice (Non-Veg)', 550.00, 1, '550.00', '2022-09-09 16:48:02', 'Ordered', 'Gautam Aryal', '9847387545', 'gtmaryal101@gmail.com', 'Baluwatar Kathmandu'),
(24, 'Crispy Wings', 300.00, 1, '300.00', '2022-09-09 17:31:26', 'Ordered', 'Gautam Aryal', '9847387545', 'gtmaryal101@gmail.com', 'Baluwatar Kathmandu');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_food`
--
ALTER TABLE `tbl_food`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tbl_food`
--
ALTER TABLE `tbl_food`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
