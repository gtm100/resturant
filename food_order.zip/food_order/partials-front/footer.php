  <!-- social Section Starts Here -->
  <section class="social">
        <div class="container text-center">
            <ul>
                <li>
                    <a href="#"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
                </li>
                <li>
                    <a href="#"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
                </li>
                <li>
                    <a href="#"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
                </li>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->

    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
            <p>All rights reserved. Designed By <a href="#">Prashanta koirala</a></p>
        </div>
    </section>
    <!-- footer Section Ends Here -->
   <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
            
    $.post("<?php echo HOMEURL; ?>add_to_cart.php", { }, function (data){
            $('#cart').html(data);
        });
        
        function addToCart (product_id)
        {
            $.post("<?php echo HOMEURL; ?>add_to_cart.php", { product_id: product_id}, function (data){
                alert(data + ' has been added to your cart.')
                $('#cart').html(data);
            });
    
        }
    </script>