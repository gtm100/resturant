

   <?php include("config/constants.php"); ?>
<!--:note: hami li partials-front bata bahera niskina pardaina because menu aaru sabi item mai xa    -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Important to make website responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Website</title>

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="css/style.css">
    <style>
        .wrapper2 {
            margin-left: 200px;
  display: grid;
  grid-template-columns: 300px 300px 300px;
  grid-gap: 10px;
  background-color: #fff;
  color: #444;
}

.box {
  /* background-color: #444; */
  /* color: #fff; */
  border-radius: px;
  padding: 20px;
  font-size: 150%;
}
    </style>
    
</head>

<body>
    <!-- Navbar Section Starts Here -->
    <section class="navbar">
        <div class="container">
            <div class="logo">
                <a href="#" title="Logo">
                    <img src="images/logo.png" alt="Restaurant Logo" class="img-responsive">
                  
                </a>
            </div>

            <div class="menu text-right">
                <ul>
                    <li>
                        <a href="<?php echo HOMEURL;?>">Home</a>
                    </li>
                    <li>
                        <a href="<?php echo HOMEURL ;?>categories.php">Categories</a>
                    </li>
                    <li>
                        <a href="<?php echo HOMEURL;?>foods.php">Foods</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div>

            <div class="clearfix"></div>
        </div>
    </section>
 


    <!-- CAtegories Section Starts Here -->
    <section class="categories">
    <h2 class="text-center">Explore Foods</h2>
        <div class="wrapper2">
           
             <?php
            //create sql qury to display catatersd from database
            $sql="SELECT * FROM tbl_category WHERE active='yes' ";

            $result=mysqli_query($conn,$sql);

            $count=mysqli_num_rows($result);

            if($count>0)
            {
                //ctagory xa
                while($row=mysqli_fetch_assoc($result))
                {
                    //get the value
                    $Id=$row['Id'];
                    $title=$row['title'];
                    $image_name=$row['image_name'];
                    ?>
               <a href="<?php echo HOMEURL;?>category-foods.php?category_Id=<?php echo $Id;?>">
                        <div class="box float-container">
                        <img src="<?php echo HOMEURL;?>images/category/<?php echo $image_name; ?>" alt="Pizza" width="200"  class="img-responsive img-curve">

                            <h3 class="float-text text-white"><?php echo $title;?></h3>
                        </div>
                        </a>
                    <?php
                }
            }
            else
            {
               // ctagory xaina
               echo " cataory not added";
            }
            ?> 
            
            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Categories Section Ends Here -->


   
 <!-- footer  -->
 <?php include("partials-front/footer.php"); ?>
    <!-- footer -->
