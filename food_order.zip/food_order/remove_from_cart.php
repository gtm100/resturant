<?php
session_start();
$product_id = $_GET['p_id'];
if ($product_id)
{
    $cart_key = 'cart_' . $product_id;
    unset($_SESSION[$cart_key]);
    include "util_functions.php";
    include "config/constants.php";

}
Redirect(HOMEURL . 'cart.php');
?>