<?php include("partials-front/menu.php"); ?>
<?php
            //php quary to display category from database
            $sql="SELECT * FROM tbl_category WHERE active='yes' AND feature='yes' LIMIT 3";
            //execute a quary
            $result=mysqli_query($conn,$sql);

            $count = mysqli_num_rows($result);  

       

            if($count>0)
            {
                //catagery avabible
                while($row=mysqli_fetch_assoc($result))
                {
                    $Id=$row['Id'];
                    $title=$row['title'];
                    $image_name=$row['image_name'];
              ?>
                    <img src="<?php echo HOMEURL;?>images/category/<?php echo $image_name; ?>" alt="Pizza" width="200" >
<?php
                    var_dump($image_name);

                }
            }
?>          <td><?php echo $status; ?></td>