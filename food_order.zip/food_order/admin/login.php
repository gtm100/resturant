<?php include('../config/constants.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>loginFoodOrder system</title>
    <link rel="stylesheet" type="text/css" href="../css/admin.css">
</head>
<body>
<div class="login">
    <h1 class="text-center"> login</h1>
<br/><br/>
<?php
if(isset($_SESSION['login']))
{
	echo $_SESSION['login'];
	unset($_SESSION['login']);
}

if(isset($_SESSION['no-login-massage']))
{
	echo $_SESSION['no-login-massage'];
	unset($_SESSION['no-login-massage']);
}
?>
    <!-- form start hare -->
    <form action="" method="post">
        UserName: 
       <input type="text" name="username" id=""><br/> <br/> 
        PassWord:
       <input type="text" name="password" id=""><br/> <br/>
      
       <input type="submit" value="login" name="submit" class="btn-primary"><br/>






    </form>

    
    </div>

</body>
</html>
<!-- check submit is click or not -->
<?php
if(isset($_POST['submit']))
{
    $uname= mysqli_real_escape_string($conn,$_POST['username']);
    $pword=mysqli_real_escape_string($conn,$_POST['password']);
    // sql quary check a user exist or not
    if ($uname!="" && $pword!="")
    {
        $sql = "SELECT * FROM tbl_admin where username ='$uname' AND password = '$pword' ";
    // execute a quary
    $result=mysqli_query($conn,$sql);
    //count rows a user is axist or not 
    $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
    $count=mysqli_num_rows($result);

    if($count==true)
    {
        //user exist
        $_SESSION['login']="<div class='success'>login successfull</div>";
        $_SESSION['user']=$uname;//to check user is login or not and logout will unset it 
        //redirect to dashbod
        header('location:'.HOMEURL.'admin/');
    }
    else
    {
        //user not exist
        $_SESSION['login']="<div class='error '>invalid username and password</div>";
        //redirect to dashbod
        header("location:".HOMEURL.'admin/login.php');
    }
 }
}
?>
