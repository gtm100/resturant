<div class="footer">
<div class = "wrapper">
<p class="text_center">2020 all right reverse, sam resudent develop by <a href="">prashant koirala</a></p>
</div>
</div>
<!-- footer end -->




</body>
</html>
