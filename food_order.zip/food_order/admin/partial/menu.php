
<?php 
include("../config/constants.php");
include('login-check.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>food_order website</title>
	<link rel="stylesheet" type="text/css" href="../css/admin.css">
</head>
<body>
<!-- nevetion start -->
<div class = "menu text_center">
	<div class = "wrapper">
	<ul>
		<li><a href="index.php"> Home</a></li>
		<li><a href="manage_admin.php"> Admin</a></li>
		<li><a href="manage_catagory.php"> Catagory</a></li>
		<li><a href="manage_food.php"> Food</a></li>
		<li><a href="manage_order.php"> Order</a></li>
		<li><a href="logout.php"> logout</a></li>
		
	</ul>
</div>
	
</div>

<!-- nevation end -->

