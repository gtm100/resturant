<?php
//authorization access control
//user is login or not  
if(!isset($_SESSION['user']))
{
//user is not login 
//redirect to login page
$_SESSION['no-login-massage']="<div class='error'> please login access Admin panal </div>";
header('location:'.HOMEURL.admin/login.php);
}


?>