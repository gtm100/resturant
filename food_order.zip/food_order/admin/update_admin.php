<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>update_admin</h1>
	<!-- button to add admin -->
    <?php
	//<!-- grt id of update  -->
 $Id=$_GET['Id'];
    //execute a queary
  //  if(isset($_POST['submit'])){
    //    $full_name=$_POST['name'];
     //   $username=$_POST['username'];



    $sql="SELECT * FROM tbl_admin WHERE Id={$Id}";
    $result = mysqli_query($conn,$sql);
    //check wherether the quary is working or not
    if($result==true){
        //echo"it work";
        //check where the data is ababile or not
        $count = mysqli_num_rows($result);
        //check whether we have admin or not
        if ($count==1)
        {
          //get a detail    
          echo"admin alibable";
          $row=mysqli_fetch_assoc($result);
         $full_name = $row['full_name'];
         $username = $row['username'];
         $Id=$row['Id'];
        }
        else 
        {
            //redirected to manage admin page
            header('location:'.$HOMEURL.'admin/manage_admin.php');
        }

    } 
   
    ?>

	<br/>
<br/>
<form action="" method="post">
    <table class="tbl-30">
<tr>
    <td>FullName: </td>
    <td><input type="text" name="full_name" value="<?php echo $full_name ;?> " id=""></td>
</tr>
<tr>
    <td>UserName: </td>
    <td><input type="text" name="username" value="<?php echo $username ; ?>" id=""></td>
</tr>
<tr>
    <td colspan="2">
        <input type="submit" name="submit"  value="update" class="btn-secondary">
         <input type="hidden" name="Id"  value="<?php echo $Id;?>" >
    </td>
</tr>



    </table>
</form>
</div>
</div>
<?php
if(isset($_POST['submit']))
{
//get all value from form
echo $Id = $_POST['Id'];
echo $fullname = $_POST['full_name'];
echo $username = $_POST['username']; 

//create a sql quary to update
$sql = "UPDATE tbl_admin SET
full_name = '$fullname',
username = '$username'
WHERE Id='$Id'
";
//execute a quary 
$result = mysqli_query($conn,$sql);
//check whether a quary is successfuly execute or not
if($result==true)
{
$_SESSION['update']="<div class ='success'> Admin update successfully.</div>";
header('location:'.HOMEURL.'admin/manage_admin.php');
}else
{
$_SESSION['update']="< div class = 'error'> Admin update successfully.</div>";
header('location:'.HOMEURL.'admin/manage_admin.php');
}
}
?>


<?php include("partial/footer.php")?>