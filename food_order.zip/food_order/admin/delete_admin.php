<?php include("partial/menu.php")?>
<?php
// include constant.php file here
include('../config/constants.php') ;
//get the id to delete admin
$Id=$_GET['Id'];

//sqli quary to delete admin
$sql="DELETE FROM tbl_admin WHERE Id = $Id";
// send a massage (success) while deleting
$result=mysqli_query($conn,$sql);

// chek quaery is exwecute
if( $result=TRUE)
{
    //echo "sussufully";
    // create a session virable to show massage to redirected page
    $_SESSION["delete"] = "<div class='success'> Admin Deleted successfully.</div>";
    //redirected a page 
    header('location:'."http://localhost:80/food_order/admin/manage_admin.php");
}
else
{
    //echo "not successfully";
     $_SESSION["delete"] = "fail to Deleted admin";
    //redirected a page 
    header('location:'.HOMEURL.'admin/manage_admin.php');
}

   


?>