<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>change password</h1>
</br></br>
<?php

	//<!-- grt id of change  -->
 if(isset($_GET['Id']))
 {
    $Id=$_GET['Id'];

 }


?>
    <form action="" method="POST">
        <table class ="tbl-30">
            <tr>
                <td>current Password:</td>
                <td><input type="password" name="old_password" id=""></td>
            </tr>
            <tr>
               <td>New passwod:</td>
               <td><input type="password" name="new_password" id=""></td>
                    
            </tr>
            <tr>
               <td>confirm passwod:</td>
               <td><input type="password" name="confirm_password" id=""></td>
                    
            </tr>
            <tr>
                <input type="hidden" name="Id" value =" <?php echo $Id; ?>">
                <td colspan='2'><input type="submit" value="change password" name="submit" class="btn-secondary"></td>
           
            </tr>





        </table>
    </form>
    </div>
	</div>
<?php
//first check button is clicl or not
if(isset($_POST['submit']))
{
//echo "button click";
//extract a data from a database
//check wheter a given database password and sql are same or not
//check wheter a new and comfirm password is same or not
    $Id=$_POST['Id'];
    $corrent_password = $_POST['old_password'];
$new_password=$_POST['new_password'];
$conform_password=$_POST['confirm_password'];  


$sql="SELECT * FROM tbl_admin WHERE Id = $Id AND password ='$corrent_password'";


$result =mysqli_query($conn,$sql);


if($result==true)
{
    $count=mysqli_num_rows($result);
    if($count==1)
    {
        //echo "user found";
        if($new_password==$conform_password)
        {
            //update password
        //   echo "password match";
            $sql2 = "UPDATE tbl_admin SET
            password = '$new_password '
            WHERE Id=$Id
            ";
            //execute a quary
            $result2=mysqli_query($conn,$sql2);
            //check a quary execute or not
            if($result2==true)
            {
                //display success massage
                $_SESSION['change_password']="<div class ='success'> password change  . </div> ";
                header('location:'.HOMEURL.'admin/manage_admin.php');
            }
            else
            {
                //display errror massage
                  $_SESSION['change_password']="<div class ='success'> fail to change password  . </div> ";
                header('location:'.HOMEURL.'admin/manage_admin.php');
            }
        }
        else
        {
           // readdir to manage admin page
    $_SESSION['password_not_match']="<div class ='error'> password not match . </div> ";
    header('location:'.HOMEURL.'admin/manage_admin.php');
        }
    }
else
{
    //user does not exit 
    $_SESSION['user_not_found']="<div class ='error'> user not found . </div> ";
    header('location:'.HOMEURL.'admin/manage_admin.php');
}
}



} 

?>

	<?php include("partial/footer.php")?>