<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>manage_food</h1>
	<br/><br/>
	<?php
if(isset($_SESSION['add']))
{
	echo $_SESSION['add'];
	unset($_SESSION['add']);
}

if(isset($_SESSION['delete']))
{
	echo $_SESSION['delete'];
	unset($_SESSION['delete']);
}

if(isset($_SESSION['upload']))
{
	echo $_SESSION['upload'];
	unset($_SESSION['upload']);
}

if(isset($_SESSION['unauthorized']))
{
	echo $_SESSION['unauthorized'];
	unset($_SESSION['unauthorized']);
}

if(isset($_SESSION['upload_image']))
{
	echo $_SESSION['upload_image'];
	unset($_SESSION['upload_image']);
}

?>
	<a href="<?php echo HOMEURL;?>admin/add_food.php" class="btn-primary">Add food</a>
<br/><br/>
	<table class="tbl_full">
		<tr>
			<th>S.N</th>
			<th>Title</th>
			<th>Price</th>
			<th>Image</th>
			<th>feature</th>
			<th>Active </th>
			<th>Action</th>
		</tr>
		
		
		<?php
		//Sql quary to get all the food
		$sql="SELECT * FROM tbl_food";
		//execut a quary
		$result = mysqli_query($conn,$sql);
		//count rows
		$count=mysqli_num_rows($result);
		//check 
		if($count > 0)
		{
			//we have a food on database 
			//get the food from the database and display
			while($row=mysqli_fetch_assoc($result))
			{
				//get the valu from individual colom
				$Id=$row['Id'] ;
				$title=$row['title'];
				$price=$row['price'];
				$image_name=$row['image_name'];
				$featured=$row['feature'];
				$active=$row['active'];
				?>
				<tr>
			<td><?php echo $Id; ?></td>
			<td> <?php echo $title; ?></td>
			<td><?php echo $price; ?></td>
			<td>
				<!-- check image name is abaliable or not -->
				<?php
				if(!empty($image_name))
				{
					//display image 
					?>
					<img src="<?php echo HOMEURL;?>images/food/<?php echo $image_name;?>" width="100px">

					<?php
			
				}
				else
				{
					
					//display error massage ..............................error massage display vako xaina.....
				
					echo "<div class='error'> image not selected</div>";
				}
				
				?>
			</td>
			<td><?php echo $featured; ?></td>
			<td><?php echo $active; ?></td>
			<td> <a href="<?php echo HOMEURL; ?>admin/update_food.php?Id=<?php echo $Id?>" class="btn-secondary">  UpdateFood</a>
			 <a href="<?php echo HOMEURL; ?>admin/delete_food.php?Id=<?php echo $Id?>&image_name=<?php echo $image_name?>" class="btn-danger"> DeleteFood</td></a>
		</tr>

            <?php

			}
		}
		else
		{
			//food not added on database
			echo "<tr><td colspan= '7' class='error'> food not added  </td></tr>";

		}
		
		?>
	</table>
	</div>
	</div>
	<?php include("partial/footer.php")?>