<?php include("partial/menu.php")?>

<div class="main-content">
<div class="wrapper">
<h1>Add category</h1>
<br/><br/>

<?php
if(isset($_SESSION['add']))
{
	echo $_SESSION['add'];
	unset($_SESSION['add']);
}

if(isset($_SESSION['upload_img']))
{
	echo $_SESSION['upload_img'];
	unset($_SESSION['upload_img']);
}
?>

<br/><br/>


<!-- add catagory form start -->
<form action="" method="post" enctype="multipart/form-data">
<table class="tbl-30">
<tr>
    <td>title:</td>
    <td><input type="text" name="title" id="title"></td>
</tr>
<tr>
    <td>select image:</td>
    <td><input type="file" name="image" id=""></td>
</tr>

<tr>
    <td>feature:</td>
    <td><input type="radio" name="featured" value="yes" id="">yes
    <input type="radio" name="featured" value="no" id="">no</td>
</tr>
<tr>
    <td>active:</td>
    <td><input type="radio" name="active" value="yes" id="">yes
    <input type="radio" name="active" id="" value="no">no</td>
</tr>
<tr>
   <td colspan="2">
    <input type="submit" name="submit" value="Add Category" class="btn-secondary">
</tr>


</table>
</form>
<!-- add catagory form end -->
<?php
//check submit buteen is work is not
if(isset($_POST['submit']))
{
  //  echo "click";
  // get value from catagory form
  $title=$_POST['title'];
  //for radion input we need to check weather a radio button is selected or not
  
  if(isset($_POST['featured']))
  {
    $featured = $_POST['featured']; 
  }
else
  {
    $featured='no';
  }


  if(isset($_POST['active']))
  {
    $active = $_POST['active']; 
  }
else
  {
    $active='no';
  }
//check image is upload or not
if(isset($_FILES['image']['name']));//image ko name xa vani matra upload gharni 
{
//to upload image we need image name source path and destination
$image_name=$_FILES['image']['name'];
//auto rename when same image is upload
//get a extension for upload//jpg
$ext=end(explode('.',$image_name));
//renaming image name
$image_name="food_catagory_".rand(000,999).'.'.$ext; 

$sourch_path=$_FILES['image']['tmp_name'];
$destination_path="../images/category/".$image_name;

//finaly upload image
$upload = move_uploaded_file($sourch_path,$destination_path);
//check image uplod or not
//if image is not upload we will stop a process and redirect with error massage
if($upload==false)
{
    //set massage
    $_SESSION['upload_img']="<div class='error'> image not upload .</div>";
    //redirect to add catagory page
    header('location:'.HOMEURL.'admin/add-category.php');
    //stop the process
    die();
}

}
// ..........................else ma syntex error aayo.....................//line no 110  
//...........................image upload huda active ma no aaxa yes aauni bala...........databasema

//else
//{
    //dont upload a image set a image name as a blank
  //  $image_name="";
//}


//create sql queary to insetr data  in to database
$sql="INSERT INTO tbl_category SET
title='$title',
image_name='$image_name',
feature='$featured',
active='$active'
";
$result=mysqli_query($conn,$sql);
//check wheater a quary execute or not
if($result==true)
{
    //quary execute and catagery add 
    $_SESSION['add']="<div class='success'> catagey add success full </div>";
    //redirected to manage catagery page
    header('location:'.HOMEURL.'admin/manage_catagory.php');
}
else
{
    //fail to add catagory
    $_SESSION['add']="<div class='error'> fail to add catagory </div>";
    //redirected to manage catagery page
    header('location:'.HOMEURL.'admin/add-category.php');
}
}
?>

</div>
</div>


<?php include("partial/footer.php")?>
