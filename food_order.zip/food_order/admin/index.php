<?php include("partial/menu.php")?>



<!-- nevation end -->

<!-- main contain start -->
<div class = "main_contain">
<div class = "wrapper">
	<h1>DASHBORD</h1>
<br/><br/>
<!-- ................login sussage full ko massage show vayana dassbord ma ................. -->
<?php
if(isset($_SESSION['login']))
{
	echo $_SESSION['login'];
	unset($_SESSION['login']);
}
?>
<br/><br/>


    <div class = "col-4 text_center">
			<?php
			$sql="SELECT * FROM tbl_food";
			//ececute a quary
			$result=mysqli_query($conn,$sql);
			//count
			$count=mysqli_num_rows($result);

			?>
		<h1><?php echo $count;?> </h1>
		<br/>
		catagory
	
	</div>

	<div class = "col-4 text_center">
			<?php
			$sql1="SELECT * FROM tbl_food";
			//ececute a quary
			$result1=mysqli_query($conn,$sql1);
			//count
			$count1=mysqli_num_rows($result1);

			?>
		<h1><?php echo $count1;?> </h1>
		<br/>
		food
	</div>
	<div class = "col-4 text_center">
			<?php
			$sql3="SELECT * FROM tbl_order";
			//ececute a quary
			$result3=mysqli_query($conn,$sql3);
			//count
			$count3=mysqli_num_rows($result3);

			?>
		<h1><?php echo $count3;?> </h1>
		<br/>
		Order
	</div>
	<div class = "col-4 text_center">
	  <?php
			$sql4="SELECT SUM(total) AS Total FROM tbl_order WHERE status='delivered'";
			//ececute a quary
			$result4=mysqli_query($conn,$sql4);
			//fetch
			$row4=mysqli_fetch_assoc($result4);

			$Total_revenue=$row4['Total'];
		?>
		<h1>$<?php echo $Total_revenue;?> </h1>
		<br/>
		revenu generated
	</div>
	<div class ="clearfix"> </div>

</div>
</div>

<!-- main contain  end -->

<!-- footer start -->
<div class="footer">
<div class = "wrapper">
<p class="text_center">2020 all right reverse, sam resudent develop by <a href="">prashant koirala</a></p>
</div>
</div>
<!-- footer end -->




</body>
</html>
