<?php
//include constant .php for home url
include("../config/constants.php");
//destroy the session and redirect to login page
session_destroy();
//redirection 
header('location:'.HOMEURL.'admin/login.php');


?>