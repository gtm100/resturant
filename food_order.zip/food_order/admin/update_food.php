<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>update_food</h1>
    	<br/><br/>
        <?php
   if(isset($_GET['Id']))
   {
    //get id and all detail
    //echo 'getting the data';
    $Id=$_GET['Id'];
    //create sql quary to get all other detail
    $sql2="SELECT * FROM tbl_food WHERE Id=$Id";

    //Execute a quary
    $result2 = mysqli_query($conn,$sql2);
    //count to check either a id is valid or not
    $count2 = mysqli_num_rows($result2);
    if($count2==1)
    {
        //get all the data
        $row2 = mysqli_fetch_assoc($result2);
      
        $current_image=$row2['image_name'];
        $feature=$row2['feature'];
        $active=$row2['active'];
        $title=$row2['title'];
        $description =$row2['description'];
        $price=$row2['price'];
       $current_category=$row2['category_id'];

    }
   else
   {
    //redirect to manage catagory with seccsion massage
    $_SESSION['no_category_found']="<div class='error'> food not found</div>";
    header('location:'.HOMEURL.'admin/manage_food.php');
   }
    




   }
   else
   {
    //redirect to manage catagery
    header('location:'.HOMEURL.'admin/manage_food.php');
   }
   
   ?>

    <br/><br/>

        
    <form action="" method="POST" enctype="multipart/form-data">
<table class="tbl-30">
<tr>
    <td>title:</td>
    <td><input type="text" name="title" id="title" value="<?php echo $title ;?>"></td>
</tr>
<tr>
    <td>description:</td>
    <td><textarea name="description" id="" cols="30" rows="5"><?php echo $description ;?></textarea></td>
</tr>
<tr>
    <td>price:</td>
    <td><input type="number" name="price"  value="<?php echo $price ;?>" id=""></td>
</tr>
<tr>
    <td>current image:</td>
    <td>

<?php

      if($current_image != "")

       {

         //Display the Image
       

        ?>

        <img src="<?php echo HOMEURL; ?>images/food/<?php echo $current_image; ?>" width="100px">
        <?php

       }

        else

     {

        //Display Message

        echo "<div class='error'>Image Not Added.</div>";
     }
?>

</td>

</tr>
</tr>



<tr>
    <td>select new image:</td>
    <td><input type="file" name="image"  id=""></td>
</tr>
<tr>
    <td>Category:</td>
    <td>
   <select name="category"  >
    <?php
    //create a php code to display catagery from a database
    //1.create a sql to display active catagery from a database
    $sql="SELECT * FROM tbl_category WHERE active='yes' ";
    //exeecute a quary
    $result=mysqli_query($conn,$sql);

        //count rows to checke the 
    $count=mysqli_num_rows($result);
		//check wther catagory is avabiable or not
		if($count > 0)
   {
				//we have a data in databse 
			//get a data and display using while loop
			while($row=mysqli_fetch_assoc($result))
        {
           $category_Id=$row['Id'];
            $category_title=$row['title'];
            ?>

            <option <?php if($current_category==$category_Id){echo "selected";}?> value="<?php echo $category_Id;?>"><?php echo $category_title; ?> </option>



            <?php


        }
    }
    else
    {
        //no catagory found
        ?>
        <option value="0"> no catagory found </option>
        <?php

    }
   ?>

</select>
</td>
</tr>

<tr>
    <td>feature:</td>
    <td>
        <input <?php if($feature=="yes") {echo"checked";} ?> type="radio" name="feature" value="yes">yes
        <input <?php if($feature=="no") {echo"checked";} ?> type="radio" name="feature" value="no">no
    </td>
</tr>
<tr>
    <td>active:</td>
    <td>
        <input <?php if($active=="yes") {echo"checked";} ?> type="radio" name="active" value="yes">yes
        <input <?php if($active=="no") {echo"checked";} ?> type="radio" name="active" value="no">no
    </td>
</tr>
<tr>
    <td colspan="2">
        <input type="hidden" name="Id" value="<?php echo $Id;?>">
        <input type="hidden" name="current_image" value="<?php echo $current_image?>">
        <input type="submit" value="update_food" name = "submit" class="btn-secondary">
    </td>
</tr>
<table>
</form>
<?php

//check a wther a botten is click or not
if(isset($_POST['submit']))
{

    //echo "ckick";
    //get the data from the form and send into database
    //upload the selected image
    
    $title=$_POST['title'];
    $description=$_POST['description'];
    $price=$_POST['price'];
    $Category=intval($_POST['category']);
    $Id=$_POST['Id'];
    $current_image=$_POST['current_image'];
    $feature=$_POST['feature'];
    $active=$_POST['active'];


    var_dump($Category);

    //check wheter the radio butten are check or not
  /*  if(isset($_POST['feature']))
    {
        $feature=$_POST['feature'];

    }
    else
    {
        $feature="no";
    }

    //for active we check the radion button is clicked or not
    if(isset($_POST['active']))
    {
        $active=$_POST['active'];

    }
    else
    {
        $active="no";
    } 
     //updating new image if selected
   //check wether a image is selected or not*/
   if(isset($_FILES['image']['name']))
   {
       //get the image detail
       $image_name=$_FILES['image']['name'];
       //check image is avabiable or not
       if($image_name!="")
       {
             //get a extension for upload//jpg
             $ext=end(explode('.',$image_name));
             //renaming image name
             $image_name="food_name_".rand(000,999).'.'.$ext; 

             $sourch_path=$_FILES['image']['tmp_name'];
              $destination_path="../images/food/".$image_name;
              //finaly upload image
              $upload = move_uploaded_file($sourch_path,$destination_path);
              //check image uplod or not
              if($upload==false)
             {
                //set massage
                $_SESSION['upload_image']="<div class='error'>fail to upload new image .</div>";
                 //redirect to add catagory page
                header('location:'.HOMEURL.'admin/manage_food.php');
               //stop the process
               die();
             }
             //remove current image if avabile
             if($current_image!="")
             {
                  $path = "../images/food/".$current_image;
          
                  $remove=unlink( $path);
                  //check wether a image is remove or not
                  if($remove==false)
                  {
                      //fail to remove a image
                      $_SESSION['fail image']="<div class='error'> fail to remove a image</div>";
          
                      header('location:'.HOMEURL.'admin/manage_food.php');
                      die();//stop the process
                  }
              } 
             
       }
       else
       {
        $image_name = $current_image;
       }
    }
        else
        {
            $image_name = $current_image;//setting defult valuel

        }
        //create a sql quary to save or add food
       //$sql2 = "INSERT tbl_food SET 
         // title ='$title',
         //description = '$description', 
         //price = '$price',
         //image_name='$image_name'
         //category_id=$category,
        // active=$active,
         //feature='$feature'

          //";
          $sql3 = "UPDATE tbl_food SET title ='$title', description ='$description', category_id='$category', price=$price, feature = '$feature', active = '$active',image_name='$image_name' WHERE Id=$Id";
          
          //execute a Query
          $result3 = mysqli_query($conn , $sql3); 
          //redirect to manage catagory with massage
          //check wether quary execute or not
         
         if($result3=true)
         {
           //catagery update
            $_SESSION['add'] = "<div class='success'> food update </div>";
          header('location:'. HOMEURL.'admin/manage_food.php');

         }
         else
        {
         //failed to update category
         $_SESSION['add'] = "<div class='error'> fail to update food</div>";
        header('location:'. HOMEURL.'admin/manage_food.php');

        }






}




  

?>

</div>
</div>
<?php include("partial/footer.php")?>

