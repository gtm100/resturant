<?php

// $image_name =  'food_catagory_356.jpg';

// var_dump($_GET['image_name']);
// $path= "../images/category/".$image_name; 

// var_dump(file_exists($path)); die();
/*//Include Constants File

include('../config/constants.php');

//echo "Delete Page";

//Check whether the id and image name value is set or not
   if(isset($_GET['Id']) AND isset($_GET['image_name']))
{
 //"get value and delete" 
 $Id = $_GET['Id']; 
 $image_name = $_GET["image_name"];

// Remove the physical Image file is available
 
 if($image_name!=""){
 
 //Image Is Available. So remove it
 
 $path= "../images/category/".$image_name; 
 //REmove the image
 
 $remove = unlink($path);
 
 // failed to remove Image then add an error message and stop the process
 
 if($remove== false) {
 //set the Session Message
 
 $_SESSION['remove'] = "<div class='error'>Falle to Remove Category Image.</div>"; 
 //Redirect to manage category page 
 header('location:'.HOMEURL.'admin/manage-catagory.php');
  //stop the Process
 
 die();
 }
}
 //Delete Data from Database
 $sql="DELETE FROM tbl_category WHERE Id=$Id ";
 //execute a quary
 $result = mysqli_query($conn,$sql);
 //check wether a data is delete or not
 if($result==true)
 {
    //Set success massage and redirect
    $_SESSION['delete']="<div class='error'> fail to delete catagory</div>";
 //Redirect to Manage Category Page with Message
 header('location:'.HOMEURL.'admin/manage-catagory.php');
 }
}
else
{
 
 //redirect to Manage Category Page 
 header('location:'.HOMEURL. 'admin/manage-catagory.php');
}*/
?> 




<?php include("partial/menu.php")?>
<?php
// include constant.php file here
include('../config/constants.php') ;
//get the id to delete admin
$Id=$_GET['Id'];

$image_location = "SELECT image_name FROM tbl_category WHERE Id = $Id"; 



$path= "../images/category/".$image_name; 

//sqli quary to delete admin
$sql="DELETE FROM tbl_category WHERE Id = $Id";
// send a massage (success) while deleting
$result=mysqli_query($conn,$sql);

// chek quaery is exwecute
if( $result=TRUE)
{
   unlink($path);
    //echo "sussufully";
    // create a session virable to show massage to redirected page
    $_SESSION["delete"] = "<div class='success'> catagery Deleted successfully.</div>";
    //redirected a page 
    header('location:'."http://localhost:80/food_order/admin/manage_catagory.php");
}
else
{
    //echo "not successfully";
     $_SESSION["delete"] = "fail to Deleted catagery";
    //redirected a page 
    header('location:'.HOMEURL.'admin/manage_catagory.php');
}

   


?>