<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>manage_admin</h1>
	<!-- button to add admin -->
		<br/><br/>
	<a href="add-admin.php" class="btn-primary">add_admin</a>
<br/><br/>
<?php
if(isset($_SESSION['add']))
{
	echo $_SESSION['add'];
	unset($_SESSION['add']);
}

if(isset($_SESSION['delete']))
{
	echo $_SESSION['delete'];
	unset($_SESSION['delete']);
}

if(isset($_SESSION['update']))
{
	echo $_SESSION['update'];
	unset($_SESSION['update']);
}

if(isset($_SESSION['user_not_found']))
{
	echo $_SESSION['user_not_found'];
	unset($_SESSION['user_not_found']);
}

if(isset($_SESSION['password_not_match']))
{
	echo $_SESSION['password_not_match'];
	unset($_SESSION['password_not_match']);
}

if(isset($_SESSION['change_password']))
{
	echo $_SESSION['change_password'];
	unset($_SESSION['change_password']);
}


?>
          <table class="table_admin" border="1" >
		<tr>
			<th>S.N</th>
			<th>FullName</th>
			<th>UserName</th>
			<th style="width:400px">Action</th>
		</tr>
		<?php
        //reads all the rows form database table 
        $sql="select * from tbl_admin";
		$result=mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result))
        {?>
		<tr>
                    <td><?php echo $row['Id']; ?></td>
                    <td><?php echo $row['full_name']; ?></td>
					 <td><?php echo $row['username']; ?></td>
                    
					<td style="height:50px">
					<a href="<?php echo HOMEURL;?>admin/update_password.php ?Id=<?php echo $row['Id'];?> " class="btn-primary"> change Password</a>
			        <a href="<?php echo HOMEURL;?>admin/update_admin.php ?Id=<?php echo $row['Id'];?> " class="btn-secondary"> UpdateAdmin</a>
					<a href="<?php echo HOMEURL;?>admin/delete_admin.php ?Id=<?php echo $row['Id'];?> " class="btn-danger"> DeleteAdmin</a>
		            </td>

                    
                      
                <tr>
            <?php
		}
		?>
			
      
	</table>
	</div>
	</div>
	<?php include("partial/footer.php")?>