<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>update admin</h1>
	<br/> <br/>
<form action="add-admin.php" method="post">
	<table class="tbl-30">
		<tr>
			<td>full Name:</td>
			<td><input type="text" name="full_name"></td>
		</tr>
		<tr>
			<td>user Name:</td>
			<td><input type="text" name="username"></td>

		</tr>
		<tr>
			<td>password:</td>
			<td><input type="password" name="password"></td>

		</tr>
		<tr>
			<td colspan="2"><input type="submit" name="submit" value="update" class="btn-primary">

		</tr>
	</table>
</form>
</div>
</div>
<?php include("partial/footer.php")?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food_order";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if(! $conn )  
{  
  die('Could not connect: ' . mysqli_error());  
}  
echo 'Connected successfully';  
$sql="SELECT * FROM tbl_admin WHERE Id={$Id}";
    $result = mysqli_query($conn,$sql);




mysqli_close($conn);
?>