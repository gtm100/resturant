<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>add_food</h1>
    	<br/><br/>
        <?php
        if(isset($_SESSION['upload_image']))
        {
            echo $_SESSION['upload_image'];
            unset($_SESSION['upload_image']);
        }
        ?>
        <br/><br/>

        
    <form action="" method="POST" enctype="multipart/form-data">
<table class="tbl-30">
<tr>
    <td>title:</td>
    <td><input type="text" name="title" id="title" value="<?php //echo $title ;?>"></td>
</tr>
<tr>
    <td>description:</td>
    <td><textarea name="description" id="" cols="30" rows="5"></textarea></td>
</tr>
<tr>
    <td>price:</td>
    <td><input type="number" name="price" id=""></td>
</tr>
<tr>
    <td>select image:</td>
    <td><input type="file" name="image" id=""></td>
</tr>
<tr>
    <td>Category:</td>
    <td>
   <select name="category"  >
    <?php
    //create a php code to display catagery from a database
    //1.create a sql to display active catagery from a database
    $sql="SELECT * FROM tbl_category WHERE active='yes' ";
    //exeecute a quary
    $result=mysqli_query($conn,$sql);

        //count rows to checke the 
    $count=mysqli_num_rows($result);
		//check 
		if($count > 0)
   {
				//we have a data in databse 
			//get a data and display using while loop
			while($row=mysqli_fetch_assoc($result))
        {
            $Id=$row['Id'];
            $title=$row['title'];
            ?>

            <option value="<?php echo $Id;?>"><?php echo $title; ?> </option>



            <?php


        }
    }
    else
    {
        //no catagory found
        ?>
        <option value="0"> no catagory found </option>
        <?php

    }
   ?>
    






</select>
</td>
</tr>

<tr>
    <td>feature:</td>
    <td>
        <input type="radio" name="feature" value="yes">yes
        <input type="radio" name="feature" value="no">no
    </td>
</tr>
<tr>
    <td>active:</td>
    <td>
        <input type="radio" name="active" value="yes">yes
        <input type="radio" name="active" value="no">no
    </td>
</tr>
<tr>
    <td colspan="2">
        <input type="submit" value="add_food" name = "submit" class="btn-secondary">
    </td>
</tr>
<table>
</form>
<?php

//check a wther a botten is click or not
if(isset($_POST['submit']))
{

    //echo "ckick";
    //get the data from the form and send into database
    //upload the selected image
    
    $title=$_POST['title'];
    $description=$_POST['description'];
    $price=$_POST['price'];
    $Category=intval($_POST['category']);

    var_dump($Category);

    //check wheter the radio butten are check or not
    if(isset($_POST['feature']))
    {
        $feature=$_POST['feature'];

    }
    else
    {
        $feature="no";
    }

    //for active we check the radion button is clicked or not
    if(isset($_POST['active']))
    {
        $active=$_POST['active'];

    }
    else
    {
        $active="no";
    } 
     //updating new image if selected
   //check wether a image is selected or not
   if(isset($_FILES['image']['name']))
   {
       //get the image detail
       $image_name=$_FILES['image']['name'];
       //check image is avabiable or not
       if($image_name!="")
       {
             //get a extension for upload//jpg
             $ext=end(explode('.',$image_name));
             //renaming image name
             $image_name="food_catagory_".rand(000,999).'.'.$ext; 

             $sourch_path=$_FILES['image']['tmp_name'];
              $destination_path="../images/food/".$image_name;
              //finaly upload image
              $upload = move_uploaded_file($sourch_path,$destination_path);
              //check image uplod or not
              if($upload==false)
             {
                //set massage
                $_SESSION['upload_image']="<div class='error'> image not upload .</div>";
                 //redirect to add catagory page
                header('location:'.HOMEURL.'admin/manage_food.php');
               //stop the process
               die();
             }

       }
    }
        else
        {
            $image_name = "";//setting defult valuel

        }
        //create a sql quary to save or add food
       //$sql2 = "INSERT tbl_food SET 
         // title ='$title',
         //description = '$description', 
         //price = '$price',
         //image_name='$image_name'
         //category_id=$category,
        // active=$active,
         //feature='$feature'

          //";
          $sql2 = "INSERT INTO tbl_food (title, description, price,active,feature,image_name , category_id)
          VALUES ('$title', '$description', $price,'$active','$feature', '$image_name','$Category' )";
          //execute a Query
          $result2 = mysqli_query($conn , $sql2); 
          //redirect to manage catagory with massage
          //check wether quary execute or not
         if($result2=true)
         {
           //catagery update
            $_SESSION['add'] = "<div class='success'> food added </div>";
            header('location:'. HOMEURL.'admin/manage_food.php');

         }
         else
        {
         //failed to update category
         $_SESSION['add'] = "<div class='error'> fail to add food</div>";
         header('location:'. HOMEURL.'admin/manage_food.php');

        }






}




  

?>

</div>
</div>
<?php include("partial/footer.php")?>