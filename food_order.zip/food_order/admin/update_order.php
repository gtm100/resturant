<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>Update order</h1>
    	<br/><br/>
       
        <!--  -->
        <?php
   if(isset($_GET['Id']))
   {
    //get id and all detail
    //echo 'getting the data';
    $Id=$_GET['Id'];
    //create sql quary to get all other detail
    $sql2="SELECT * FROM tbl_order WHERE Id=$Id";

    //Execute a quary
    $result2 = mysqli_query($conn,$sql2);
    //count to check either a id is valid or not
    $count2 = mysqli_num_rows($result2);
    if($count2==1)
    {
        //get all the data
        $row2 = mysqli_fetch_assoc($result2);
      
        $food=$row2['food'];
        $Qty=$row2['qty'];
        $status=$row2['status'];
      
    }
   else
   {
    //redirect to manage catagory with seccsion massage
    $_SESSION['no_category_found']="<div class='error'> food not found</div>";
    header('location:'.HOMEURL.'admin/manage_order.php');
   }
    




   }
   else
   {
    //redirect to manage catagery
    header('location:'.HOMEURL.'admin/manage_food.php');
   }
   
   ?>

    <br/><br/>


        <!--  -->
        <form action="" method="post">
            <table class="tbl-30">
                <tr>
                    <td> Food Name</td>
                    <td><b> <?php echo $food;?></b> </td>
                </tr>
                <tr>
                    <td> Qty</td>
                    <td> <input type="number" name="qty" value="<?php echo $Qty;?>">  </td>
                </tr>
                <tr>
                    <td>Status</td>
                    <td>
                        <select name="status" >
                            <option <?php if($status=="Ordered") { echo "selected";}?> value="Ordered">Ordered</option>
                            <option <?php if($status=="On delivery") { echo "selected";}?>  value="On delivery">On delivery</option>
                            <option <?php if($status=="delivered") { echo "selected";}?> value="delivered">delivered</option>
                            <option <?php if($status=="cancelled") { echo "selected";}?> value="cancelled">cancelled</option>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <input type="submit" value="Update Order" name ="submit" class="btn-secondary" >
                    </td>
                </tr>

            </table>
        </form>
            <?php
        if(isset($_POST['submit']))
            {
                $Qty=$_POST['qty'];
                $status=$_POST['status'];
                //updating the value
                $sql="UPDATE tbl_order SET
                qty=$Qty,
                status='$status'
                WHERE Id=$Id";
                //execut a quary 
                $sql=mysqli_query($conn,$sql);
                if($sql==true)
                {
                    $_SESSION['update_food_order']="<div class='success'> custermur update</div>";
                    header('location:'.HOMEURL.'admin/manage_order.php');

                }
                else
                {
                    $_SESSION['update_food_order'] = "<div class='error'> fail to update  </div>";
                    header('location:'.HOMEURL.'admin/manage_order.php');
                }
            }
            ?>

</div>
</div>
<?php include("partial/footer.php")?>