<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>update catagery</h1>
	<br/> <br/>
   <!-- check whether a id is set or not  -->
   <?php
   if(isset($_GET['Id']))
   {
    //get id and all detail
    //echo 'getting the data';
    $Id=$_GET['Id'];
    //create sql quary to get all other detail
    $sql="SELECT * FROM tbl_category WHERE Id=$Id";

    //Execute a quary
    $result = mysqli_query($conn,$sql);
    //count to check either a id is valid or not
    $count = mysqli_num_rows($result);
    if($count==1)
    {
        //get all the data
        $row = mysqli_fetch_assoc($result);
      
        $current_image=$row['image_name'];
        $feature=$row['feature'];
        $active=$row['active'];
        $title=$row['title'];

    }
   else
   {
    //redirect to manage catagory with seccsion massage
    $_SESSION['no_category_found']="<div class='error'> catagory not fount</div>";
    header('location:'.HOMEURL.'admin/manage_catagory.php');
   }
    




   }
   else
   {
    //redirect to manage catagery
    header('location:'.HOMEURL.'admin/manage_catagory.php');
   }
   
   ?>

    <br/><br/>
<!-- add catagory form start -->
<form action="" method="post" enctype="multipart/form-data">
<table class="tbl-30">
<tr>
    <td>title:</td>
    <td><input type="text" name="title" id="title" value="<?php echo $title ;?>"></td>
</tr>
<tr>
    <td>current image:</td>
    <td>

<?php

      if($current_image != "")

       {

         //Display the Image
       

        ?>

        <img src="<?php echo HOMEURL; ?>images/category/<?php echo $current_image; ?>" width="100px">
        <?php

       }

        else

     {

        //Display Message

        echo "<div class='error'>Image Not Added.</div>";
     }
?>

</td>

</tr>
</tr>
<tr>
    <td>new image:</td>
    <td><input type="file" name="image" id=""></td>
</tr>
<tr>
    <td>feature:</td>
    <td><input <?php if ($feature=="yes"){echo "checked";}?> type="radio" name="featured" value="yes" id="">yes
    <input <?php if ($feature=="no"){echo "checked";}?> type="radio" name="featured" value="no" id="">no</td>
</tr>
<tr>
    <td>active:</td>
    <td><input  <?php if ($active=="yes"){echo "checked";}?>  type="radio" name="active" value="yes" id="">yes
    <input  <?php if ($active=="no"){echo "checked";}?>      type="radio" name="active" id="" value="no">no</td>
</tr>
<tr>
<td>
    <input type="submit" name="submit" value="update Category" class="btn-secondary"> 
    <input type="hidden" name="Id" value="<?php echo $Id;?>">
    <input type="hidden" name="current_image" value ="<?php echo $current_image;?>"> 
</td>
</tr>



</table>
</form>
<?php
//check if update button is work or not
if(isset($_POST['submit']))
{
    //echo "clock";
    //get all the value from our form 
    

                $Id=$_POST['Id'];
			//	$current_image=$_POST['current_image'];
				$title=$_POST['title'];
				$feature=$_POST['featured'];
				$active=$_POST['active'];

    //updating new image if selected
    //check wether a image is selected or not
if(isset($_FILES['image']['name']))
{
    //get the image detail
    $image_name=$_FILES['image']['name'];
    //check image is avabiable or not
    if($image_name!="")
    {
        //image is avabiable

        //upload the new image 
        //auto rename when same image is upload
//get a extension for upload//jpg
$ext=end(explode('.',$image_name));
//renaming image name
$image_name="food_catagory_".rand(000,999).'.'.$ext; 

$sourch_path=$_FILES['image']['tmp_name'];
$destination_path="../images/category/".$image_name;

//finaly upload image
$upload = move_uploaded_file($sourch_path,$destination_path);
//check image uplod or not
//if image is not upload we will stop a process and redirect with error massage
if($upload==false)
{
    //set massage
    $_SESSION['upload_img']="<div class='error'> image not upload .</div>";
    //redirect to add catagory page
    header('location:'.HOMEURL.'admin/manage_catagory.php');
    //stop the process
    die();
}

        //delete the current image if avabiables
        if($current_image!="")
   {
        $path = "../images/category/".$current_image;

        $remove=unlink( $path);
        //check wether a image is remove or not
        if($remove==false)
        {
            //fail to remove a image
            $_SESSION['fail image']="<div class='error'> fail to remove a image</div>";

            header('location:'.HOMEURL.'admin/manage_catagory.php');
            die();//stop the process
        }
    } 
    }
    else
    {
        $image_name=$current_image;
    }
}
else 
{
    //
    $image_name=$current_image;
}
//updating the database 
$sql2 = "UPDATE tbl_category SET title ='$title',feature = '$feature', active = '$active',image_name='$image_name' WHERE Id=$Id";

//$sql2="UPDATE tbl_category SET
//title = '$title',
//feature = '$feature',
//active = '$active',
//WHERE Id = $Id";

  //execute a Query
  $result2 = mysqli_query($conn , $sql2);
     
    

  //redirect to manage catagory with massage
  //check wether quary execute or not
  if($result2=true)
  {
      //catagery update
      $_SESSION['update'] = "<div class='success'> catagory update successfull</div>";
      header('location:'. HOMEURL.'admin/manage_catagory.php');

  }
  else
  {
      //failed to update category
      $_SESSION['update'] = "<div class='error'> fail to update catagory</div>";
      header('location:'. HOMEURL.'admin/manage_catagory.php');

  }
    
   
}
?>



</div>
</div>
<?php include("partial/footer.php")?>