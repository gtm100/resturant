<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>manage_catagory</h1>
	<br/><br/>
	<?php
if(isset($_SESSION['add']))
{
	echo $_SESSION['add'];
	unset($_SESSION['add']);
}

if(isset($_SESSION['remove']))
{
	echo $_SESSION['remove'];
	unset($_SESSION['remove']);
}

if(isset($_SESSION['delete']))
{
	echo $_SESSION['delete'];
	unset($_SESSION['delete']);
}

if(isset($_SESSION['no_category_found']))
{
	echo $_SESSION['no_category_found'];
	unset($_SESSION['no_category_found']);
}

if(isset($_SESSION['update']))
{
	echo $_SESSION['update'];
	unset($_SESSION['update']);
}

if(isset($_SESSION['upload_img']))
{
	echo $_SESSION['upload_img'];
	unset($_SESSION['upload_img']);
}
?>

<br/><br/>
	<a href="<?php echo HOMEURL;?>admin/add-category.php" class="btn-primary">Add catager</a>
<br/><br/>
	<table class="tbl_full">
		<tr>
			<th>.S.N</th>
			<th>Title</th>
			<th>Image </th>
			<th>feature</th>
			<th>Active</th>
			<th>Action</th>
		</tr>

		<?php
		///quary to get all file from a database
		$sql="SELECT * FROM tbl_category";
		//execute quary 
		$result=mysqli_query($conn,$sql);
		//count rows
		$count=mysqli_num_rows($result);
		//check 
		if($count > 0)
		{
			//we have a data in databse 
			//get a data and display using while loop
			while($row=mysqli_fetch_assoc($result))
			{
				$Id=$row['Id'];
				$image_name=$row['image_name'];
				$title=$row['title'];
				$feature=$row['feature'];
				$active=$row['active'];
				?>
				
				<tr>
			<td><?php echo $Id; ?></td>
			<td><?php echo $title; ?></td>

			<td>
				<!-- check image name is abaliable or not -->
				<?php 
				
				if($image_name!=" ")
				{
					//display image 
					?>
					<img src="<?php echo HOMEURL;?>images/category/<?php echo $image_name;?>" width="100px">

					<?php
			
				}
				else
				{
					//display error massage ..............................error massage display vako xaina.....
					echo "image not found"; 
				}
				
				?>
			</td>

			<td><?php echo $feature; ?></td>
			<td><?php echo $active;?></td>
			<td> <a href="<?php echo HOMEURL;?>admin/update_category.php?Id=<?php echo $Id;?>" class="btn-secondary">  UpdateCategory</a>
			 <a href="<?php echo HOMEURL;?>admin/delete_category.php?Id=<?php echo $Id ; ?>&image_name=<?php echo $image_name?>" class="btn-danger"> DeleteCategory</td></a>
		</tr>




				<?php

			}
		}
		else
		{
			//we do not have data in a databse
			//we will display a massage inside a tabel
			//so we will break a php and add html
			?>
			<tr>
			<td colspan="5"><div class="error"> No Catagory Added</div></td>
			</tr>





			<?php

		}
		
		?>
	
	</table>
	</div>
	</div>
<?php include("partial/footer.php")?>