<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>add admin</h1>
	<br/> <br/>

	<?php
if(isset($_SESSION['add'])){
	echo $_SESSION['add'];//display session massage
	unset($_SESSION['add']);//unset session massage 
}

	?>
<form action="add-admin.php" method="post">
	<table class="tbl-30">
		<tr>
			<td>full Name:</td>
			<td><input type="text" name="full_name"></td>
		</tr>
		<tr>
			<td>user Name:</td>
			<td><input type="text" name="username"></td>

		</tr>
		<tr>
			<td>password:</td>
			<td><input type="password" name="password"></td>

		</tr>
		<tr>
			<td colspan="2"><input type="submit" name="submit" value="Addadmin" class="btn-primary">

		</tr>
	</table>
</form>

</div></div>

<?php include("partial/footer.php")?>
<?php //process the value from form and process into database
//check wheather a submit buttom is click or not
if(isset($_POST['submit']))
{


//1.get data from a form
$username = $_POST['username'];
$password = $_POST['password'];
$full_name = $_POST['full_name'];  


// // 
//create a sql quary to insert into a database	
//$servername = "localhost";
// $username = "root";
//$password = "";
//$dbname = "food_order";

// Create connection
//$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
//if(! $conn )  
//{  
 // die('Could not connect: ' . mysqli_error());  
//}  
//echo 'Connected successfully';  

$sql = "INSERT INTO tbl_admin (full_name, username, password)
VALUES ('$full_name', '$username', '$password')";

$result=mysqli_query($conn, $sql) or die(mysqli_error());
   if ($result==TRUE){
   	//data insert
   //	echo "data insert";
   	//create a session virable to dispay massage
   	$_SESSION['add']="admin added sussefully";
   	//redirect page
   	header("location:" .HOMEURL.'admin/manage_admin.php');

   }else{
   	//echo "fail to data insert";
   	 	//create a session virable to dispay massage
   	$_SESSION["add"]="failed to added admin";
   	//redirect page
   	header("location:" .HOMEURL.'admin/add-admin.php');

   	}




mysqli_close($conn);








}

	?>
