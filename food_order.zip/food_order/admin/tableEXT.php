<?php include("partial/menu.php")?>
<div class = "main_contain">
<div class = "wrapper">
	<h1>data Extraction learn  from database</h1>
	<br/><br/>
	<a href="" class="btn-primary">table create</a>
<br/><br/>
	<table class="tbl_full">
<tbody>
		<tr>
			<th>.S.N</th>
			<th>FullName</th>
			<th>UserName</th>
			<th>Action</th>
		</tr>
        <?php
        //reads all the rows form database table 
        $sql="select * from tbl_admin";
		$result=mysqli_query($conn, $sql);
        while($row = mysqli_fetch_assoc($result))
        {

       
		     echo"<tr>
			<td>".$row["Id"]."</td>
			<td>".$row["full_name"]."</td>
			<td>".$row["username"]."</td>
            <td>".$row["password"]."</td>
            </tr> 
                    
           ";
        }
        ?>
</tbody>	
	</table>
	</div>
	</div>
	<?php include("partial/footer.php")?>