<?php
// include constant.php file here
include('../config/constants.php') ;

///Check whether the id and image name value is set or not
   if(isset($_GET['Id']) AND isset($_GET['image_name']))
{
      
      //get id and image name 
        $Id = $_GET['Id']; 
        $image_name = $_GET["image_name"];
        //remove the image if avabable
        if($image_name!="")
        {
 
            //Image Is Available. So remove it
            
            $path= "../images/food/".$image_name; 
            //REmove the image from the folder
            
            $remove = unlink($path);//true xa vani delete gharxa
            if($remove== false) 
            {
                //set the Session Message
                $_SESSION['upload'] = "<div class='error'>Falle to Remove Category Image.</div>"; 
                //Redirect to manage category page 
                header('location:'.HOMEURL.'admin/manage_food.php');
                //stop the Process
                
                die();
            }


        }

            //deleting food from database
             $sql="DELETE FROM tbl_food WHERE Id=$Id ";
            //execute a quary
            $result = mysqli_query($conn,$sql);
            //check wether a data is delete or not
            if($result==true)
            {
                //food delete
                //Set success massage and redirect
                $_SESSION['delete']="<div class='success'>  delete food</div>";
                //Redirect to Manage_food Page with Message
                header('location:'.HOMEURL.'admin/manage_food.php');
            }
            else
            {
                //fail to delete food
                $_SESSION['delete']="<div class='error'> fail to delete food</div>";
                
                //redirect to Manage_food Page 
                header('location:'.HOMEURL. 'admin/manage_food.php');
            }


 

}
else
{
   // echo "direct to manage food page";
   //echo "not successfully";
   $_SESSION["unauthorized"] = "unauthorized access";
   //redirected a page 
   header('location:'.HOMEURL.'admin/manage_food.php');

}

?>