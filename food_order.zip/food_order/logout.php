<?php
    session_start();
    unset($_SESSION['customer_login']);
    unset($_SESSION['customer_name']);       
    unset($_SESSION['customer_id']);
    unset($_SESSION['customer_email']);

    # redirect to home page
    include "config/constants.php";
    include "util_functions.php";
    Redirect(HOMEURL, false);
?>