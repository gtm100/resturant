<?php include("partials-front/menu.php"); ?>
<!-- fOOD sEARCH Section Starts Here -->
 <section class="food-search text-center">
    <div class="container">
         <h1 style="color: white;">Hi <?php echo $_GET['name'] ?>,  have been register successfully now you can <a href="<?php echo HOMEURL ?>login.php">login</a> to your account to make orders.</h1>
    </div>
 </section>
 <?php include("partials-front/footer.php"); ?>
</body>
</html>
