<?php include("partials-front/menu.php"); ?>
<?php
include "util_functions.php";
if (!isset($_SESSION['customer_login'])) {  Redirect(HOMEURL, false); } 
?>

<?php
// form submition for signup

$id = $_SESSION['customer_id'];
$slct_query = "SELECT * from customer where c_id = $id";
$result = mysqli_query($conn, $slct_query);
if (mysqli_num_rows($result))
{
    $row = mysqli_fetch_assoc($result);
}
else
{
    echo "<h1> Sorry No User Found</h1>";
    exit();
}
    
?>
<style>
    tr th{
        padding-left: 10px !important;
        padding-right: 10px !important;
    }
</style>
 <section class="food-search text-center">
     <div class="container">
         <h1 style="color: yellow;"><u>Hi <?php echo $row['name']; ?>, Your Information as below, </u></h1>
          <h3>Email: <?php echo $row['email']; ?></h3>
          <h3>Phone No: <?php echo $row['phone_no']; ?></h3>
          <h3>Address: <?php echo $row['address']; ?></h3>     
           
          <br>
          <h1 style="color: yellow;"><u>Your recent order history:</u></h1>
            <caption>Your Cart</caption>
<table>
    <thead>
    <tr>
        <th class="primary">SN</th>
        <th class="primary">Food</th>
        <th class="primary">Price</th>
        <th class="primary">Quantity</th>
        <th class="primary">Total</th>
        <th class="primary">Date</th>
        <th class="primary">Status</th>
    </tr>
    </thead>

    <tbody>
    <?php
    $order_query = "select * from tbl_order where customer_email = '" . $_SESSION['customer_email'] ."'  order by id desc";
    $result =  mysqli_query($conn, $order_query);
    $count = 0;
    while($row = mysqli_fetch_assoc($result)) {
    ?>
    <tr>
        <td><?php echo ++$count; ?></td>
        <td>
            <b><i><?php echo $row['food'] ?></i></b>
        </td>
        <td>Rs.<?php echo $row['price']; ?></td>
        <td> <?php echo $row['qty']; ?></td>
        <td>Rs. <?php echo $row['total']; ?></td>
        <td> <?php echo $row['order_date']; ?></td>
        <td> <?php echo $row['status']; ?></td>
    </tr>
<?php } ?>  
    </tbody>
</table>
     </div>
 </section>
<?php include "partials-front/footer.php" ?>
</body>
</html>
