<?php
session_start();
if (isset($_POST['product_id']))
{
    $product_id =  $_POST['product_id'];
    $count = 0;
    $cart_key = 'cart_' . $product_id;

    if (isset($_SESSION[$cart_key]))
    {
        $_SESSION[$cart_key] += 1;
    }
    else {
        $_SESSION[$cart_key] = 1;
    }

}

function findTotal ()
{
    $total = 0;
    foreach ($_SESSION as $key => $value)
    {
        $sub_key = substr($key, 0, 5);
        if ($sub_key == "cart_")
            $total += $value;
    }
    return $total;
}

$total = findTotal();
 if  ($total > 1)
    echo $total . " Items";
 else
    echo $total .  " Item";
?>