

    <?php include("partials-front/menu.php"); ?>
    <?php
            //check wether id is pass or not
            if(isset($_GET['category_Id']))
            {
                //catagey id is set 
                //get the id
                $category_Id=$_GET['category_Id'];

                $sql="SELECT title from tbl_category WHERE Id=$category_Id";
                //execute a quary
                $result=mysqli_query($conn,$sql);

             
                $row = mysqli_fetch_assoc($result);    

                $category_title=$row['title'];
            }
            else
            {
                //catagery is not set 
                header('location:'.HOMEURL);
            }
 
 ?>
 

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search text-center">
        <div class="container">
            
            <h2>Foods on <a href="#" class="text-white"><?php echo $category_title;?></a></h2>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->



    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>
            <?php
                //create sql qury to display catatersd from database
                $sql2="SELECT * FROM tbl_food WHERE category_id=$category_Id ";

                $result2=mysqli_query($conn,$sql2);

                $count2=mysqli_num_rows($result2);
              //  var_dump($count2>0);

                if($count2>0)
                {
                    //food Availabel
                    while($row=mysqli_fetch_assoc($result2))
                    {
                        //get the value
                       $Id=$row['Id'];
                        $title=$row['title'];
                        $price=$row['price'];
                        $description=$row['description'];
                        $image_name=$row['image_name'];
            ?>
                      <div class="food-menu-box">
                        <div class="food-menu-img">
                        <img src="<?php echo HOMEURL;?>images/food/<?php echo $image_name; ?>"  class="img-responsive img-curve">
                        </div>

                        <div class="food-menu-desc">
                            <h4><?php echo $title;?></h4>
                            <p class="food-price">Rs.<?php echo $price;?></p>
                            <p class="food-detail">
                            <?php echo $description;?>
                            </p>
                            <br>

                            <button  class="btn btn-primary" onclick="addToCart(<?php echo $Id; ?>)">Add to cart</button>
                        </div>
                    </div>

                       
                    <?php
                }
            }
            else
            {
              echo "<div class='error'> Food Not Available</div>";
            }
            ?> 


           


            <div class="clearfix"></div>

            

        </div>

    </section>
    <!-- fOOD Menu Section Ends Here -->

   
 <!-- footer  -->
 <?php include("partials-front/footer.php"); ?>
    <!-- footer -->
