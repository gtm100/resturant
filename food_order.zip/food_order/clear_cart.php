<?php
session_start();
foreach ($_SESSION as $key => $value)
{
    $sub_key = substr($key, 0, 5);
    if ($sub_key == "cart_")
    {
        unset($_SESSION[$key]);
    }
}
include "util_functions.php";
include "config/constants.php";
Redirect(HOMEURL . 'cart.php');
?>