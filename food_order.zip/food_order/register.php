<?php include("partials-front/menu.php"); ?>
 
 <!-- fOOD sEARCH Section Starts Here -->
 <section class="food-search text-center">
     <div class="container">
         <h1>Register Now </h1>
         
         
         <form action="<?php echo HOMEURL ;?>register.php" method="POST">
             <input type="text" class="form-input" name="name" placeholder="Enter your full name" required minlength="6"><br>
             <input type="text" class="form-input" name="address" placeholder="Enter your address" required minlength="6"><br>
             <input type="email" class="form-input" name="email" placeholder="Enter your email" required minlength="6"><br>
             <input type="tel" class="form-input" name="phone_no" placeholder="Enter your Phone Number" pattern="[+]{0,1}[0-9]{8,15}" required><br>
             <input type="password" class="form-input" name="password" placeholder="Enter your password" required minlength="6"><br>
             <br>
             <input type="submit" name="submit" value="register" class="btn btn-primary btn-custm">
         </form>
        <label><a href="<?php echo HOMEURL; ?>login.php">Or already have a account</a></label>
     </div>
 </section>
 <?php include("partials-front/footer.php"); ?>
</body>
</html>

<?php
// form submition for signup
if (isset($_POST['submit']))
{
    $name = $_POST['name'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $phone_no = $_POST['phone_no'];
    $password = MD5($_POST['password']);

    //create table customer (c_id int AUTO_INCREMENT, name varchar(50) not null, address varchar(50) not null, email varchar(50) not null, phone_no varchar(20) not null, password varchar(100) not null, activation_code int, status int(1) default 1, PRIMARY KEY(c_id));    
    $email_slct_query = "SELECT email from customer where email = '" . $email . "'";
    #echo $email_slct_query;
    $result = mysqli_query($conn, $email_slct_query);
    if (mysqli_num_rows($result))
    {
        echo "<script>alert('This email already exits please try with another email');</script>";        
    }
    else
    {
        $register_sql = "insert into customer(name, address, email, phone_no, password) values('" .  $name . "', '" . $address . "', '". $email . "', '" . $phone_no . "', '" . $password . "')";
        #echo $register_sql;
        if (mysqli_query($conn, $register_sql))
        {
            echo '<script type="text/javascript">location.href = "' . HOMEURL . 'register_success.php?name=' . $name . '";</script>'; 
        }

    }
}
?>