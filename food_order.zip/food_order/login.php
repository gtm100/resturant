<?php include("partials-front/menu.php"); ?>
 <section class="food-search text-center">
     <div class="container">
         <h1>User Login </h1>

         
         <form action="<?php echo HOMEURL ;?>login.php" method="POST">
             <input type="email" class="form-input" name="email" placeholder="Enter your email" required><br>
             <input type="password" class="form-input" name="password" placeholder="Enter your password" required><br>
             <br>
             <input type="submit" name="submit" value="Login" class="btn btn-primary btn-custm">
         </form>
         
         <label ><a href="<?php echo HOMEURL; ?>register.php" class="form_label">Or create a new account</a></label>
     </div>
 </section>
<?php include "partials-front/footer.php" ?>
</body>
</html>
<?php
// form submition for signup
if (isset($_POST['submit']))
{
    $email = $_POST['email'];
    $password = MD5($_POST['password']);

    //create table customer (c_id int AUTO_INCREMENT, name varchar(50) not null, address varchar(50) not null, email varchar(50) not null, phone_no varchar(20) not null, password varchar(100) not null, activation_code int, status int(1) default 1, PRIMARY KEY(c_id));    
    $email_slct_query = "SELECT * from customer where email = '" . $email . "' AND password = '" . $password ."'";
    #echo $email_slct_query;
    $result = mysqli_query($conn, $email_slct_query);
    if (mysqli_num_rows($result))
    {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['customer_login'] = 1;
        $_SESSION['customer_name'] = $row['name'];       
        $_SESSION['customer_id'] = $row['c_id'];
        $_SESSION['customer_contact'] = $row['phone_no'];
        $_SESSION['customer_email'] = $email;
        $_SESSION['customer_address'] = $row['address'];
        echo '<script type="text/javascript">location.href = "' . HOMEURL . '";</script>'; 
    }
    
    else
    {
        echo "<script>alert('Invalid email or password. Tryagain!');</script>";        
    }
}
?>