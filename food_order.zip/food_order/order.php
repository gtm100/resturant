<?php include("partials-front/menu.php"); ?>

<section class="food-search text-center">
     <div class="container">
    
     <?php
$items = [];
foreach ($_SESSION as $key => $value)
{
    $sub_key = substr($key, 0, 5);
    if ($sub_key == "cart_")
    {
        $id = substr($key, 5);
        array_push($items, $id);
    }
}
$count = 0;
$grand_total = 0;
if(!count($items))
{
    echo "<H1>Your cart is empty.</H1>";
}
else
{
?>
     <table>

    <h1 style="color:white;">Your order has been added successfully. Your order will be deliver as soon as possible. Thank you for.</h1>

<thead>
  <tr>
    <th class="primary">SN</th>
    <th class="primary">Product</th>
    <th class="primary">Price</th>
    <th class="primary">Quantity</th>
    <th class="primary">Total</th>
  </tr>
</thead>

<tbody>
<?php
foreach ($items as $item) {
$item_query = "select * from tbl_food where id = $item";
$result =  mysqli_query($conn, $item_query);
$row = mysqli_fetch_assoc($result);
?>
<tr>
    <td><?php echo ++$count; ?></td>
    <td>
        <img src="<?php echo HOMEURL;?>images/food/<?php echo $row['image_name']; ?>"  class="img-responsive img-curve" style="height:50px; width:50px;">
        <br>
        <b><i><?php echo $row['title'] ?></i></b>
    </td>
    <td>RS.<?php echo $row['price']; ?></td>
    <td> <?php echo $_SESSION['cart_' . $item]; ?> Items</td>
    <td>RS. <?php $total =  $row['price'] * $_SESSION['cart_' . $item]; $grand_total += $total; echo $total;?></td>
  </tr>
<?php } ?>  
<tr>
    <td colspan="3"> Grand Total: RS. <?php echo $grand_total ?></td>
    <?php if (isset($_SESSION['customer_login'])) { ?>
    <td colspan="2">Thank you.</td>
</tr>
</tbody>

</table>
<?php  } } ?>        
     </div>
 </section>
<?php include "partials-front/footer.php" ?>
</body>
</html>
<?php
$items = [];
foreach ($_SESSION as $key => $value)
{
    $sub_key = substr($key, 0, 5);
    if ($sub_key == "cart_")
    {
        $id = substr($key, 5);
        array_push($items, $id);
    }
}
$count = 0;
$grand_total = 0;

foreach ($items as $item) {
    $item_query = "select * from tbl_food where id = $item";
    $result =  mysqli_query($conn, $item_query);
    $row = mysqli_fetch_assoc($result);
    $title = $row['title'];
    $price = $row['price'];
    $qty = $_SESSION['cart_' . $item];
    $total = $price * $qty;
    $name = $_SESSION['customer_name'];
    $contact = $_SESSION['customer_contact'];
    $email = $_SESSION['customer_email'];
    $address = $_SESSION['customer_address'];
    $insert_query = "insert into tbl_order(
        food,
        price,
        qty,
        total,
        order_date,
        status,
        customer_name,
        customer_contact,
        customer_email, customer_address) values(
            '$title',
                $price,
                $qty,
                $total,
                NOW(),
                'Ordered',
                '$name',
                '$contact',
                '$email',
                '$address'
            
        )";
    mysqli_query($conn, $insert_query);
    //  clear card
foreach ($_SESSION as $key => $value)
{
    $sub_key = substr($key, 0, 5);
    if ($sub_key == "cart_")
    {
        unset($_SESSION[$key]);
    }
}
}

?> 
